--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5 (Debian 11.5-1.pgdg90+1)
-- Dumped by pg_dump version 11.5 (Debian 11.5-1+deb10u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE django;
--
-- Name: django; Type: DATABASE; Schema: -; Owner: django
--

CREATE DATABASE django WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE django OWNER TO django;

\connect django

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: core_movie; Type: TABLE; Schema: public; Owner: django
--

CREATE TABLE public.core_movie (
    id integer NOT NULL,
    title character varying(140) NOT NULL,
    plot text NOT NULL,
    year integer NOT NULL,
    rating integer NOT NULL,
    runtime integer NOT NULL,
    website character varying(200) NOT NULL,
    director_id integer,
    CONSTRAINT core_movie_runtime_check CHECK ((runtime >= 0)),
    CONSTRAINT core_movie_year_check CHECK ((year >= 0))
);


ALTER TABLE public.core_movie OWNER TO django;

--
-- Name: core_movie_id_seq; Type: SEQUENCE; Schema: public; Owner: django
--

CREATE SEQUENCE public.core_movie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_movie_id_seq OWNER TO django;

--
-- Name: core_movie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django
--

ALTER SEQUENCE public.core_movie_id_seq OWNED BY public.core_movie.id;


--
-- Name: core_movie_writers; Type: TABLE; Schema: public; Owner: django
--

CREATE TABLE public.core_movie_writers (
    id integer NOT NULL,
    movie_id integer NOT NULL,
    person_id integer NOT NULL
);


ALTER TABLE public.core_movie_writers OWNER TO django;

--
-- Name: core_movie_writers_id_seq; Type: SEQUENCE; Schema: public; Owner: django
--

CREATE SEQUENCE public.core_movie_writers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_movie_writers_id_seq OWNER TO django;

--
-- Name: core_movie_writers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django
--

ALTER SEQUENCE public.core_movie_writers_id_seq OWNED BY public.core_movie_writers.id;


--
-- Name: core_person; Type: TABLE; Schema: public; Owner: django
--

CREATE TABLE public.core_person (
    id integer NOT NULL,
    first_name character varying(140) NOT NULL,
    last_name character varying(120) NOT NULL,
    born date NOT NULL,
    died date
);


ALTER TABLE public.core_person OWNER TO django;

--
-- Name: core_person_id_seq; Type: SEQUENCE; Schema: public; Owner: django
--

CREATE SEQUENCE public.core_person_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_person_id_seq OWNER TO django;

--
-- Name: core_person_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django
--

ALTER SEQUENCE public.core_person_id_seq OWNED BY public.core_person.id;


--
-- Name: core_role; Type: TABLE; Schema: public; Owner: django
--

CREATE TABLE public.core_role (
    id integer NOT NULL,
    name character varying(140) NOT NULL,
    movie_id integer NOT NULL,
    person_id integer NOT NULL
);


ALTER TABLE public.core_role OWNER TO django;

--
-- Name: core_role_id_seq; Type: SEQUENCE; Schema: public; Owner: django
--

CREATE SEQUENCE public.core_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_role_id_seq OWNER TO django;

--
-- Name: core_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django
--

ALTER SEQUENCE public.core_role_id_seq OWNED BY public.core_role.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: django
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO django;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: django
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO django;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: core_movie id; Type: DEFAULT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_movie ALTER COLUMN id SET DEFAULT nextval('public.core_movie_id_seq'::regclass);


--
-- Name: core_movie_writers id; Type: DEFAULT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_movie_writers ALTER COLUMN id SET DEFAULT nextval('public.core_movie_writers_id_seq'::regclass);


--
-- Name: core_person id; Type: DEFAULT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_person ALTER COLUMN id SET DEFAULT nextval('public.core_person_id_seq'::regclass);


--
-- Name: core_role id; Type: DEFAULT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_role ALTER COLUMN id SET DEFAULT nextval('public.core_role_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Data for Name: core_movie; Type: TABLE DATA; Schema: public; Owner: django
--

COPY public.core_movie (id, title, plot, year, rating, runtime, website, director_id) FROM stdin;
\.
COPY public.core_movie (id, title, plot, year, rating, runtime, website, director_id) FROM '$$PATH$$/2918.dat';

--
-- Data for Name: core_movie_writers; Type: TABLE DATA; Schema: public; Owner: django
--

COPY public.core_movie_writers (id, movie_id, person_id) FROM stdin;
\.
COPY public.core_movie_writers (id, movie_id, person_id) FROM '$$PATH$$/2920.dat';

--
-- Data for Name: core_person; Type: TABLE DATA; Schema: public; Owner: django
--

COPY public.core_person (id, first_name, last_name, born, died) FROM stdin;
\.
COPY public.core_person (id, first_name, last_name, born, died) FROM '$$PATH$$/2922.dat';

--
-- Data for Name: core_role; Type: TABLE DATA; Schema: public; Owner: django
--

COPY public.core_role (id, name, movie_id, person_id) FROM stdin;
\.
COPY public.core_role (id, name, movie_id, person_id) FROM '$$PATH$$/2924.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: django
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/2926.dat';

--
-- Name: core_movie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: django
--

SELECT pg_catalog.setval('public.core_movie_id_seq', 3, true);


--
-- Name: core_movie_writers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: django
--

SELECT pg_catalog.setval('public.core_movie_writers_id_seq', 7, true);


--
-- Name: core_person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: django
--

SELECT pg_catalog.setval('public.core_person_id_seq', 22, true);


--
-- Name: core_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: django
--

SELECT pg_catalog.setval('public.core_role_id_seq', 6, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: django
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 4, true);


--
-- Name: core_movie core_movie_pkey; Type: CONSTRAINT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_movie
    ADD CONSTRAINT core_movie_pkey PRIMARY KEY (id);


--
-- Name: core_movie_writers core_movie_writers_movie_id_person_id_1ce1004e_uniq; Type: CONSTRAINT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_movie_writers
    ADD CONSTRAINT core_movie_writers_movie_id_person_id_1ce1004e_uniq UNIQUE (movie_id, person_id);


--
-- Name: core_movie_writers core_movie_writers_pkey; Type: CONSTRAINT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_movie_writers
    ADD CONSTRAINT core_movie_writers_pkey PRIMARY KEY (id);


--
-- Name: core_person core_person_pkey; Type: CONSTRAINT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_person
    ADD CONSTRAINT core_person_pkey PRIMARY KEY (id);


--
-- Name: core_role core_role_movie_id_person_id_name_b2b6b66b_uniq; Type: CONSTRAINT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_role
    ADD CONSTRAINT core_role_movie_id_person_id_name_b2b6b66b_uniq UNIQUE (movie_id, person_id, name);


--
-- Name: core_role core_role_pkey; Type: CONSTRAINT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_role
    ADD CONSTRAINT core_role_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: core_movie_director_id_0df6f676; Type: INDEX; Schema: public; Owner: django
--

CREATE INDEX core_movie_director_id_0df6f676 ON public.core_movie USING btree (director_id);


--
-- Name: core_movie_writers_movie_id_6a53c7e4; Type: INDEX; Schema: public; Owner: django
--

CREATE INDEX core_movie_writers_movie_id_6a53c7e4 ON public.core_movie_writers USING btree (movie_id);


--
-- Name: core_movie_writers_person_id_abb709f8; Type: INDEX; Schema: public; Owner: django
--

CREATE INDEX core_movie_writers_person_id_abb709f8 ON public.core_movie_writers USING btree (person_id);


--
-- Name: core_role_movie_id_3e74205c; Type: INDEX; Schema: public; Owner: django
--

CREATE INDEX core_role_movie_id_3e74205c ON public.core_role USING btree (movie_id);


--
-- Name: core_role_person_id_1127a6da; Type: INDEX; Schema: public; Owner: django
--

CREATE INDEX core_role_person_id_1127a6da ON public.core_role USING btree (person_id);


--
-- Name: core_movie core_movie_director_id_0df6f676_fk_core_person_id; Type: FK CONSTRAINT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_movie
    ADD CONSTRAINT core_movie_director_id_0df6f676_fk_core_person_id FOREIGN KEY (director_id) REFERENCES public.core_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_movie_writers core_movie_writers_movie_id_6a53c7e4_fk_core_movie_id; Type: FK CONSTRAINT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_movie_writers
    ADD CONSTRAINT core_movie_writers_movie_id_6a53c7e4_fk_core_movie_id FOREIGN KEY (movie_id) REFERENCES public.core_movie(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_movie_writers core_movie_writers_person_id_abb709f8_fk_core_person_id; Type: FK CONSTRAINT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_movie_writers
    ADD CONSTRAINT core_movie_writers_person_id_abb709f8_fk_core_person_id FOREIGN KEY (person_id) REFERENCES public.core_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_role core_role_movie_id_3e74205c_fk_core_movie_id; Type: FK CONSTRAINT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_role
    ADD CONSTRAINT core_role_movie_id_3e74205c_fk_core_movie_id FOREIGN KEY (movie_id) REFERENCES public.core_movie(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_role core_role_person_id_1127a6da_fk_core_person_id; Type: FK CONSTRAINT; Schema: public; Owner: django
--

ALTER TABLE ONLY public.core_role
    ADD CONSTRAINT core_role_person_id_1127a6da_fk_core_person_id FOREIGN KEY (person_id) REFERENCES public.core_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

